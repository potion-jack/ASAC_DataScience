from flask import Flask, render_template, request

app = Flask( __name__ )

@app.route("/")
def root():
    return "<h1>hello falsk</h1>" #response 

@app.route("/hw2form")
def hw2form():
    return render_template('hw2form.html')

@app.route("/hw2formproc")
def hw2formproc():
    myname = request.args['myname']
    mytel = request.args['mytel']
    myemail = request.args['myemail']
    size = request.args['size']
    topping = request.args.getlist('topping')
    topping = '-'.join(topping)
    mytime = request.args['mytime']
    extraorder = request.args['extraorder']
    return render_template('hw2formproc.html', myname=myname, mytel=mytel,
                                             myemail=myemail, size=size, topping=topping,mytime=mytime,extraorder=extraorder)


@app.route("/boottest")
def boottest():
    return render_template('boottest.html')


if __name__ == "__main__":
    app.run( host = '0.0.0.0', port=4000, debug=True)