from flask import Flask, render_template, request 

app = Flask( __name__ ) 

@app.route("/") 
def root():
    return "<h1>hello flask</h1>"

@app.route("/pizzacheck") 
def pizzacheck():
    return render_template("pizzacheck.html")

@app.route("/pizzaproc") 
def pizzaproc():
    myname = request.args["myname"] # 성명
    myphone = request.args["myphone"] # 전화번호
    myemail = request.args["myemail"] # 이메일
    pizzasize = request.args["pizzasize"] # 피자사이즈
    select = request.args.getlist("select") # 토핑선택
    select ="-".join(select)
    hopetime = request.args["hopetime"] # 희망배송시간
    mytxt = request.args["mytxt"] # 배송요청사항
    return render_template("pizzaproc.html", myname=myname, myphone=myphone, myemail=myemail,
                                            pizzasize = pizzasize, select=select, 
                                            hopetime = hopetime, mytxt=mytxt)

if __name__ == "__main__":
    app.run(host = "0.0.0.0", port=4000, debug = True) 
    