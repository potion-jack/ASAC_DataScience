from flask import Flask, render_template, request # 클래스 가져오기

#from cal import 함수명 

app = Flask( __name__ ) # "__main__" 임포트 된건가 아니면 실행된건가

@app.route("/", methods=["POST","GET"]) # 명령어
def mmain():
    return render_template("main.html")

@app.route("/piz", methods=["POST","GET"]) # 명령어
def pizz():
    return render_template("pizza.html")

@app.route("/order", methods=["POST","GET"]) # 명령어
def ordd():

    myname = request.form.get("myname")
    mytel = request.form.get("mytel")
    mymail = request.form.get("mymail")
     
    mysize = request.form.get("mysize")   
    mytop = request.form.getlist("mytop")
    mytop = ", ".join(mytop)

    hoptime = request.form.get("hoptime")  
    hopes = request.form.get("hopes")  
    return render_template("order.html", myname = myname, mytel = mytel, mymail = mymail, mysize= mysize, mytop = mytop, hoptime = hoptime, hopes = hopes)



@app.route("/phi", methods=["POST","GET"]) # 명령어
def trvv():
    return render_template("phi.html")

@app.route("/thai", methods=["POST","GET"]) # 명령어
def trvvv():
    return render_template("thai.html")

@app.route("/vet", methods=["POST","GET"]) # 명령어
def trvvvv():
    return render_template("vet.html")

@app.route("/trv", methods=["POST","GET"]) # 명령어
def trv():
    return render_template("travel.html")



if __name__ == "__main__" :
    app.run(host = "0.0.0.0", port=4000, debug = True) # 포트번호 프로세스 식별자, 0.0.0.0 모든 요청에 대해서 응답하겠다.

