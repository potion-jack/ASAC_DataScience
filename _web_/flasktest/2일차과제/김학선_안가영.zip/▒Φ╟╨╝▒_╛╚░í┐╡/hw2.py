from flask import Flask, render_template, request
import sys

app = Flask(__name__)

@app.route("/")
def root():
    return "<h1>hello flask</h1>"

@app.route("/order")
def order():
    return render_template("order.html")

@app.route("/orderProc")
def orderProc():
    myname = request.args['myname']
    mytel = request.args['mytel']
    myemail = request.args['myemail']
    size = request.args['size']
    topping = request.args.getlist('topping')
    topping = ' '.join(topping)
    deltime = request.args['deltime']
    mytxt = request.args['mytxt']
    return render_template("orderProc.html", myname=myname, mytel=mytel, myemail=myemail,
                           size=size, topping=topping, deltime=deltime, mytxt=mytxt)

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=4000, debug=True) # debug=True ; 코드변경 시, 자동 디버그.